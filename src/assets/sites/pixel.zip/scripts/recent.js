try {
    const recentImg = [...document.querySelectorAll('.recent__left-item')],
          recentCube = [...document.querySelectorAll('.recent__cube:not(.recent__cube-last)')],
          recentBtn = document.querySelector('.recent__next');
for (let i = 0; i < recentCube.length; i++) {
   recentCube[i].parentElement.style.zIndex = 20-i;
   recentCube[i].addEventListener('click', function(e){
       e.preventDefault();
       for (let k = 0; k < recentCube.length; k++) {
           recentImg[k].classList.remove('active');
           recentCube[k].classList.remove('active');
       }
       this.classList.add('active');
       recentImg[i].classList.add('active');
   })
}
recentBtn.addEventListener('click', function(e){
    e.preventDefault();
    let active = recentCube.findIndex(item => item.classList.contains('active'));
    for (let k = 0; k < recentCube.length; k++) {
        recentImg[k].classList.remove('active');
        recentCube[k].classList.remove('active');
    }
    active++;
    if(active == recentCube.length) active = 0;
    recentCube[active].classList.add('active');
    recentImg[active].classList.add('active');
})
} catch (e) {
    
}
// if(location.pathname == '/' || location.pathname == '/index.html'){

// }