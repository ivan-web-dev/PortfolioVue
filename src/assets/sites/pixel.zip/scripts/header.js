const headerBtn = document.querySelector('.header__btn'),
      headerList = document.querySelector('.header__list'),
      headerAbs = document.querySelector('.header__abs'),
      header = document.querySelector('.header');
window.addEventListener('scroll', function(){
    if(this.scrollY > 200) header.classList.add('active');
    else header.classList.remove('active');
})
headerBtn.addEventListener('click', function(e){
    e.preventDefault();
    this.classList.toggle('active');
    document.body.classList.toggle('active');
    headerList.classList.toggle('active');
    headerAbs.classList.toggle('active');
})
headerAbs.addEventListener('click', function(e){
    this.classList.remove('active');
    document.body.classList.remove('active');
    headerList.classList.remove('active');
    headerBtn.classList.remove('active');
});